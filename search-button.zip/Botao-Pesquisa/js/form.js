document.querySelector("#botao-pesquisar").addEventListener("click", function(evento){

	evento.preventDefault();

	var element = document.querySelector("#div-pesquisa");

	
	$(element).fadeIn( 1000 ).addClass("mudar");


	var elemento = document.querySelector("#intPesqisa");
	elemento.focus();
	setTimeout(function(){

       elemento.style.width = "35%"; // o parentNode no js e o pai do componene que foi clicado   

   }, 500);
	

	var element = document.querySelector("#sugestoes");
	element.classList.add("ficar-invisivel-sugestoes");
	var element = document.querySelector("#sugestoes");

	setTimeout(function(){

        $(element).fadeIn("slow") // o parentNode no js e o pai do componene que foi clicado   

    }, 500);
	


});




document.querySelector("#fechar").addEventListener("click", function(evento){

	
	var element = document.querySelector("#div-pesquisa");


	$(element).fadeOut("slow");

	

});



